import csv
from typing import List
from mathstats import MathStats
from collections import Counter

def main():

  # Считываем данные из файла Retail.csv
  data = read_data("Retail.csv")
  # Считываем данные из файла MarketingSpend.csv
  data2 = MathStats("MarketingSpend.csv").data

  
  print("Кол-во элементов Invoice:", count_invoice(data))
  print("Кол-во уникальных элементов StockCode:", count_different_values(data, "StockCode"))
  print("Количество 22178-х элементов StockCode:", get_total_quantity(data, 22178))
  print("Средние значения продаж:", MathStats("MarketingSpend.csv").get_mean(data2)) #mean() - среднее число
  print("Максимальные продажи:", MathStats("MarketingSpend.csv").max)
  print("Минимальные продажи:", MathStats("MarketingSpend.csv").min)
  
  print("Дисперсия продаж:", MathStats("MarketingSpend.csv").disp)
  print("Среднеквадратическое отклонение продаж:", MathStats("MarketingSpend.csv").sigma_sq)

  return 0

# Считывание данных из файла и возвращение в виде списка словарей
def read_data(file_name: str) -> List[dict]:

  # Объявляем список
  data_list = []
  # Открываем файл для чтения
  file_Retail = open(file_name, 'r')
  # Считываем содержимое
  data = csv.DictReader(file_Retail)
  # Работаем со всеми строками - приводим данные к типу int
  for _line in data:
    _line["InvoiceNo"] = int(_line["InvoiceNo"])
    _line["StockCode"] = int(_line["StockCode"])
    _line["Quantity"] = int(_line["Quantity"])
    # Добавляем полученные данные в созданный ранее список
    data_list.append(_line)
    # Возвращаем список словарей
  return data_list

# Функция определения количества уникальных элементов Invoice
def count_invoice(data: List[dict]) -> int:

  # Объявляем счётчик
  count = 0

  # 1. Создаем список инвойсов (пустой), пробегаемся по
  # data и если в списке нет очередного инвойса, то добавляем его туда
  # в конце считаем сколько элементов в нем есть.
  """
  # 1-Й СПОСОБ ЧЕРЕЗ СПИСОК
  # Создаем список инвойсов (пустой)
  invoice_list = []
  # Обрабатываем данные (по data)
  for _element in data:
    # Проверяем, содержатся ли данные в списке
    if _element["InvoiceNo"] not in invoice_list:
      # Если в списке нет очередного инвойса, то добавляем его туда
      invoice_list.append(_element["InvoiceNo"])
      # Увеличиваем счётчик
      count += 1
  """

  # 2. Создаем множество и добавляем туда по очереди все встреченные
  # элементы. Поскольку это множество, инвойсы в нем не будут
  # повторяться. В конце считаем сколько элементов.
  """
  # 2-Й СПОСОБ ЧЕРЕЗ МНОЖЕСТВО
  # Создаём множество
  elements = set()
  # Обрабатываем данные (по data)
  for _element in data:
    # Добавляем по очереди все встреченные элементы. Инвойсы в нем не будут повторяться.
    elements.add(_element["InvoiceNo"])
  # Считаем количество элементов
  count = len(elements)
  """
  # 3-Й СПОСОБ ЧЕРЕЗ COUNTER
  # Объявляем список
  c_invoice_list = [
    # Обрабатываем данные (по data)
    _element["InvoiceNo"] for _element in data
  ]
  # Подсчитываем уникальные элементы через количество элементов счётчика
  count = len(Counter(c_invoice_list))
  return count

# Функция определения общего числа уникальных значений для столбца key в списке data
def count_different_values(data: List[dict], key: str) -> int:

  # Объявляем счётчик
  count = 0
  """
  # 1-Й СПОСОБ ЧЕРЕЗ СПИСОК
  # Объявляем список
  elements_list = []
  # Обрабатываем данные (по data)
  for _element in data:
    # Проверяем, содержатся ли данные в списке
    if _element[key] not in elements_list:
      # Если в списке нет очередного значения, то добавляем его туда
      elements_list.append(_element[key])
      # Увеличиваем счётчик
      count += 1
  """

  """
  # 2-Й СПОСОБ ЧЕРЕЗ МНОЖЕСТВО
  # Объявляем множество
  elements = set()
  # Обрабатываем данные (по data)
  for _element in data:
    # Добавляем по очереди все встреченные элементы. Значения не будут повторяться.
    elements.add(_element[key])
  # Считаем количество элементов
  count = len(elements)
  """

  # 3-Й СПОСОБ ЧЕРЕЗ COUNTER
  # Объявляем список
  elements_list = [
    # Обрабатываем данные (по data)
    _element[key] for _element in data
  ]
    
  # Подсчитываем уникальные элементы через количество элементов счётчика
  count = len(Counter(elements_list))
  return count
  
# Функция определения общего числа проданных товаров по конкретному Stoсk_Code
def get_total_quantity(data: List[dict], stockcode: int) -> int:
  # Объявляем счётчик
  counter = 0
  # Обрабатываем данные (по data)
  for _element in data:
    # Если StockCode совпадает в записи с введённым,
    if _element["StockCode"] == stockcode:
      # то увеличиваем счётчик на число единиц товара в записи
      counter += _element["Quantity"]
  return counter

if __name__ == '__main__':
  main()
