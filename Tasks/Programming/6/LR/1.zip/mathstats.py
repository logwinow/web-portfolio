"""
Для вычисления дисперсии и ср. квадр. отклонения использовать 
https://myslide.ru/documents_3/b9d7b50c38e81a4b8b7645742d3b22c7/img10.jpg
"""

class MathStats():
    def __init__(self, file):
      # Импорт библиотеки CSV
      import csv
      # Объявляем свойства для хранения: 
      # Имени файла
      self._file = file
      # Содержимого файла
      self._data = []
      # Средних значений
      self._mean = None
      # Максимальных значений
      self._max = None
      # Минимльных значений
      self._min = None


      for _r in csv.DictReader(open(self._file, newline='')):
        row = {
          'Date': _r[''],
          'Offline': float(_r['Offline Spend']),
          'Online': float(_r['Online Spend']),
        }
        self._data.append(row)

    @property
    def data(self):
        return self._data
      
   # Вычисление среднего по оффлайн и онлайн тратам
    def get_mean(self, data):
      
      # Объявляем словарь
      sums = {'offline': 0, 'online': 0}
      # Обрабатываем данные (по data)
      for _element in data:
        # Суммируем онлайн продажи
        sums['online'] += _element['Online']
        # Суммируем офлайн продажи
        sums['offline'] += _element['Offline']
      # Среднее по онлайн
      sums['online'] /= len(data)
      # Среднее по офлайн
      sums['offline'] /= len(data)
      # Передаём значения словаря
      self._mean = sums
      return self._mean

    @property
  # Определение максимальных элементов
    def max(self):
      # Объявляем словарь
      max_dict = {'offline': float('-Inf'), 'online': float('-Inf')}
      # Обрабатываем данные (по data)
      for _element in self._data:
        # Если текущий элемент больше чем максимальный элемент,
        if _element['Online'] > max_dict['online']:
          # то присваиваем значение текущего элемента максимальному элементу
          max_dict['online'] = _element['Online']
        # Если текущий элемент больше чем максимальный элемент,
        if _element['Offline'] > max_dict['offline']:    
          # то присваиваем значение текущего элемента максимальному элементу
          max_dict['offline'] = _element['Offline']
      # Передаём значения словаря
      self._max = max_dict
      return self._max

    @property
  # Определение минимальных элементов
    def min(self):
      min_dict = {'offline': float('Inf'), 'online': float('Inf')}
      # Обрабатываем данные (по data)
      for _element in self._data:
        # Если текущий элемент меньше чем максимальный элемент,
        if _element['Online'] < min_dict['online']:
          # то присваиваем значение текущего элемента минимальному элементу
          min_dict['online'] = _element['Online']
        # Если текущий элемент меньше чем максимальный элемент,
        if _element['Offline'] < min_dict['offline']:
          # то присваиваем значение текущего элемента минимальному элементу
          min_dict['offline'] = _element['Offline']
      # Передаём значения словаря
      self._min = min_dict
      return self._min

    @property
  # Вычисление дисперсии для онлайн и офлайн продаж
    def disp(self):
      # Вычисляем средние значения
      mean = self.get_mean(self._data)
      # Объявляем словарь 
      disp_dict = {'offline': 0, 'online': 0}
      # Обрабатываем данные (по data)
      for _element in self._data:
        # Суммируем онлайн продажи
        disp_dict['online'] += (_element['Online'] - mean['online']) * (_element['Online'] - mean['online'])
        # Суммируем офлайн продажи
        disp_dict['offline'] += (_element['Offline'] - mean['offline']) * (_element['Offline'] - mean['offline'])
      # Дисперсия онлайн продаж
      disp_dict['online'] /= len(self._data)
      # Дисперсия офлайн продаж
      disp_dict['offline'] /= len(self._data)
      # Передаём значения словаря
      self._disp = disp_dict
      return self._disp

    @property
  # Вычисление среднеквадратических отклонений
    def sigma_sq(self):
      from math import sqrt
      
      # Объявляем словарь
      sigma_dict = {'offline': 0, 'online': 0}
      # Вычисляем квадратный корень из дисперсии онлайн продаж
      sigma_dict['online'] = round(sqrt(self.disp['online']), 2)
      # Вычисляем квадратный корень из дисперсии офлайн продаж
      sigma_dict['offline'] = round(sqrt(self.disp['offline']), 2)
      # Передаём значения словаря
      self._sigma_sq = sigma_dict
      return self._sigma_sq