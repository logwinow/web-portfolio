import math

from calcprint import print_results
from calcprint import write_log

POSSIBLE_TYPES = (int, float, tuple)
PARAMS = {
    'precision': 0.000001,
    'output_type': float,
    'possible_types': (int, float)
}


def load_params(file="params.ini"):
    """
    Загружает параметры работы калькулятора из файла, созданного пользователем

    >>>load_params(file="params.ini")
    PARAMS = {
    'precision': 0.000001,
    'output_type': float,
    'possible_types': (int, float)
    }

    """
    global PARAMS
    f = open(file, mode='r', errors='ignore')
    lines = f.readlines()
    for l in lines:
        param = l.split('=')  # param[0], param[1]
        param[1] = param[1].strip('\n')

        if param[0] != 'dest':
            param[1] = eval(param[1])
        if param[0] == 'precision':
            param[1] = float(param[1])
        if param[0] == 'output_type':
            if param[1] == 'float':
                param[1] = float
            if param[1] == 'int':
                param[1] = int
        if param[0] == 'possible_types':
            if param[1] == 'float':
                param[1] = float
            if param[1] == 'int':
                param[1] = int
            if param[1] == 'tuple':
                param[1] = tuple

        PARAMS[param[0]] = param[1]


def main():
    print("\nВведите ваши значения:")
    arg = []
    while True:
        val = input()
        try:
            if val == "":
                break
            val = float(val)
        except ValueError:
            print(
                "Введите число в правильном формате (разделитель дробной части '.') "
            )
        else:
            arg.append(val)
    print(arg)
    if len(arg) <= 1:
        print("Вы не ввели мало чисел! Программа завершена! ")
        return

    if len(arg) == 2:
        action = str(input("Введите действие: (+, -, *, /, ^, R): "))
    else:
        action = str(input("Введите действие: (+, -, *, /, R): "))
    while True:
        if (action == "+") or (action == "-") or (action == "*") or (
                action == "/") or (action == "R") or (action == "^"):
            break
        else:
            print("Некорректное действие, введите ещё раз!")
            action = input()
    print(action)

    try:
        res = calculate(*arg, action, **PARAMS)
    except Exception:
        print("Ошибка вычисления. Результат не определен")
    else:
        print(res)
    if type(res) == str:
        print("Программа остановлена!")
        return

    action = str(action).replace('', '')
    res = str(res).replace('', '')
    print_results(arg, action, res)
    write_log(arg, action, res)


def convert_precision(prec):
    """
    Возвращает целое число, соответствующее количеству знаков после запятой в переданном аргументе

    >>>convert_precision(0.000001)
    6

    >>>convert_precision("0.000001")
    6
    """
    int_prec = 0
    while prec < 1:
        prec = prec * 10
        int_prec = int_prec + 1
    return int_prec


def calculate(*args, **kwargs):
    """
    Возвращает дробное число, соответствующее результату той или иной математической операции, проводимой над введёнными числами 

    >>>calculate(1.000001, 2.000002, 3.00005, '+', **PARAMS)
    6.000053

    >>>calculate(2.0, 5.0, '^', **PARAMS)
    32
    """
    precision = convert_precision(kwargs['precision'])
    output_type = kwargs['output_type']
    print("Ваша точность: {0}".format(precision))

    # action = '+'
    if args[len(args) - 1] == '+':
        result_sum = sum(args[0:len(args) - 1])
        if type(result_sum) is not output_type:
            result_sum = output_type(result_sum)
        return result_sum
    # action = '-'
    if args[len(args) - 1] == '-':
        res = args[0]
        for n in args[1:len(args) - 1]:
            res -= n
        return round(res, precision)
    # action = '*'
    if args[len(args) - 1] == '*':
        res = 1
        for n in args[0:len(args) - 1]:
            res *= n
        return round(res, precision)
    # action = '/'
    if args[len(args) - 1] == '/':
        if 0 in args[0:len(args) - 1]:
            res = 'Ошибочка вышла! Не дели на ноль!'
            return res
        else:
            res = args[0]
            for n in args[1:len(args) - 1]:
                res /= n
            return round(res, precision)
    # action = '^'
    if args[len(args) - 1] == '^':
        if len(args) != 3:
            res = 'Ошибочка вышла! Операция требует только 2 числа!'
            return res
        else:
            res = math.pow(args[0], args[1])
            return round(res, precision)
    # action = 'Revers'
    if args[len(args) - 1] == 'R':
        res = (args[::-1])[1::]
        return res
    
    sys.exit
