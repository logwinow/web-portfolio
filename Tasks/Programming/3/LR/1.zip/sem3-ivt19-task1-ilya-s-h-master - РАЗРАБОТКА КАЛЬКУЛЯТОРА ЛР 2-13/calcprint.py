import datetime

def print_results(*args):
    # def print_results(*inp_args):
    # разложим входные аргументы по переменным

    result = args[-1]
    action = args[-2]
    operands = args[:len(args)-2]

    print('inp_args in pretty mode', operands, action, result)
    
    args_str = [] # ['1.000001', '2.000002', '3', '4', '5']
    for arg in args:
         args_str.append(str(arg))
    action.join(args_str)

    st1 = f"| {args_str[0:len(args)-2]} |{action}| = {result} |"
    print('-' * len(st1))
    print(st1)
    print('-' * len(st1))


def write_log(*args, file='calc-history.log.txt'):
    f = open(file, mode='a', errors='ignore')
    now = datetime.datetime.now()
    now = now.strftime("%d-%m-%Y %H:%M")
    result = args[-1]
    action = args[-2]

    f.write(f"{action}: {args[0:len(args)-2]} = {result} \nTime: {now} \n")
    f.close()
