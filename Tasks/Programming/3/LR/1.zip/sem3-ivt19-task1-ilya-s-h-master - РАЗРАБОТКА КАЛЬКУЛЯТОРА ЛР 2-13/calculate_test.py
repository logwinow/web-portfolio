import calculate


def test_calc_1():
    assert calculate.calculate(1, 2, "+") == 3, "Сложение не работает"


def test_calc_minus():
    assert calculate.calculate(1, -1, "-") == 2, "Вычитание"
    
    
def test_calc_2():
    assert calculate.calculate(10, 0, "/") == "деление на ноль невозможно", "Деление на ноль"


def test_calc_3():
    assert calculate.calculate(1.0, 1.0, "+") == 2.0, "Сложение чисел с плавающей точкой"


def test_calc_oper1():
    assert calculate.calculate(1, "0", "+") == "ошибка в операнде", "тип операнда - число, должна вывести сообщение об ошибке"


def test_calc_oper2():
    assert calculate.calculate("1", 0, "+") == "ошибка в операнде", "тип операнда - число, должна вывести сообщение об ошибке"

