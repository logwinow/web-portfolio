if __name__ == '__main__':

    from calculate import unittest
    from calculate import calculate
    from calculate import convert_precision
    from calculate import PARAMS
    class Test_calc(unittest.TestCase):  # создаем свой класс для тестов

      def test_packed_calc_sum(self):
        """ Проверяет правильность вычислений, в том числе тип данных """
        inp1, action = [1, 2, 3, 4, 5, 6, 7, 8, 9], "+"
        assert calculate(*inp1, action,
                         **PARAMS) == 45.0, 'Sum of list of ints from 1 to 9'
        assert type(calculate(
            *inp1, action, **PARAMS)) is type(45.0), 'Type of sum is incorrect'

      def test_precision(self):
        """ Осуществляет проверку вывода целого числа, соответствующего количеству знаков после запятой в переданном аргументе """
        assert convert_precision(0.00000001) == 8, "precision error"

unittest.main(verbosity=1) 
