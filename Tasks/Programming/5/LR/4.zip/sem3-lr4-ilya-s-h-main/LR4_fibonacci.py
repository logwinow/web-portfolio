import itertools

def fib(n):
    res_lst = [0, 1]
    if n == 0:
        return res_lst[:1]
    elif n == 1:
        return res_lst 
    elif n > 1:
        while True:
            cur_el = sum(res_lst[len(res_lst) - 2::])
            if cur_el <= n:
                res_lst.append(cur_el)
            else:
                break
        return res_lst 


class FibonacchiLst:
    def __init__(self, max_value):
        self.max_value = max_value
        self.lst = [0, 1] 
    
    def __getitem__(self, idx):
        if self.max_value < 0:
            raise IndexError(idx)
        
        if idx > 0:
            if self.max_value == 0:
                raise IndexError(idx)
                        
            if idx == 1:
                return self.lst[1]
            
            if idx == 2 and self.max_value == 1:
                raise IndexError(idx)
            
            cur_el = self.lst[0] + self.lst[1]
            del self.lst[0]
            self.lst.append(cur_el)
            
            if cur_el > self.max_value:
                raise IndexError(idx)
            
            return self.lst[1]
        
        else:
            return self.lst[0]
        
        
def fib_classic_iter():
    lst = [0, 1] 
    yield lst[0]
    yield lst[1]
    while True:
        cur_el = lst[0] + lst[1]
        del lst[0]
        lst.append(cur_el)
        yield lst[1]


def fib_iter(num_iterable):
    return itertools.takewhile(lambda x: x <= max(num_iterable), fib_classic_iter())


def main():
    print('fib():')
    print(fib(10))
    print()
    
    print('FibonacchiLst():')
    print(list(FibonacchiLst(10)))
    print()
    
    print('FibonacchiLst():')
    fib_list = FibonacchiLst(10)
    for el in fib_list:
        print(el, end=' ')
    print()
        
    
    print('fib_classic_iter():')
    g = fib_classic_iter()
    el = next(g)
    print(el, end=' ')
    while True:
        el = next(g)
        print(el, end=' ')
        if el > 10:
            break
    print()
        
            
    print('fib_iter(range(10))')
    fib_list = fib_iter(range(10))
    for el in fib_list:
        print(el, end=' ')


if __name__ == '__main__':
    main()
