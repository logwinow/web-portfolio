import io # импорт модуля io - основные инструменты для работы с потоками
import base64 # Кодирование и декодирование Base64
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs # для преобразования информации, введённой в форме

import qrcode

from db import *

# создаём переменную для генерации ссылки на страницу пользователя
SERVER_URL = 'localhost'

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    
    # обработчик GET-запросов
    def do_GET(self):      
        # Представления (View) отвечают за отображение данных модели 
        # Это модули, в которых находятся функции, выдающие HTML 
        # Они вызывают шаблонизатор, который заполняет HTML-шаблоны
        
        # подключение обработчиков представлений
        import views.client as client_view
        import views.form as form_view
        import views.message as message_view

        # код ответа сервера HTTP 200 OK
        self.send_response(200)
        #Заголовок с типом содержимого и кодировой
        self.send_header('Content-Type', 'text/html, charset="utf-8"')
        self.end_headers()
        # данные, которые будут отправлены клиенту
        result = '' 
        # по корневому маршруту отображается форма регистрации
        if self.path == '/': 
            # рендеринг формы (модуль form_view)
            result = form_view.render_form()
        # по маршруту /users отображается список пользователей
        elif self.path[:6] == '/users':
            # получение информации из json-файла (код вынесен в модуль db)
            clients = db.clients
            # рендеринг таблицы пользователей (модуль client_view)
            result = client_view.render_clients(clients)
        # по маршруту /user/{id} выводится информация о пользователе    
        elif self.path[:6] == '/user/': 
            try:
                # получаем id пользователя из url (id идёт после /user/)
                user_id = int(self.path[6:])
                # получаем информацию о пользователе с таким id
                client = db.get_user_data(user_id)
                # рендеринг страницы с информацией о пользователе (модуль client_view)
                result = client_view.render_client(client) 
            except:
                # ошибка возникает, вероятнее всего, когда после /user/ написано не число (ошибка преобразования в int)
                # или ошибка в get_user_data - нет пользователя с таким id
                # Рендеринг страницы с сообщением (модуль message_view)
                result = message_view.render_message('Пользователь с таким id не найден') 

        # преобразование отрендеренной строки (HTML страницы) в utf-8
        result = bytes(result, 'utf-8')

        # выдача страницы пользователю
        self.wfile.write(result)


    # обработчик POST-запросов
    def do_POST(self):
        # импортируем модели (Client)
        import models
        # подключение обработчика представлений (модуль message_view)
        import views.message as message_view 
        
        # код ответа сервера HTTP 200 OK 
        self.send_response(200)
        # заголовок с типом содержимого и кодировой
        self.send_header('Content-Type', 'text/html, charset="utf-8"')
        self.end_headers()

        # анализ длины полученных данных
        content_length = int(self.headers['Content-Length'])
        # чтение данных от клиента
        body = self.rfile.read(content_length)

        # данные формы (переданные в теле POST-запроса) получены в виде строки (application/x-www-form-urlencoded)
        # например: name=User&index=123&address=abcdefg (названия параметров - это значения атрибутов name у полей формы в HTML)
        
        # преобразование данных в словарь
        data = parse_qs(str(body, 'utf-8'), keep_blank_values=True)
        # метод parse_qs возвращает словарь, значениями которого являются списки
        data = {k: v[0] for k, v in data.items()} 
        # в каждом поле формы вводится одно значение, поэтому берём только первый элемент списка (используем генератор словарей)

        try:
            # создаём экземпляр класса Client с полученными и преобразованными данными
            # может возникнуть исключение, определённое в модели Client (например, указан неверный формат e-mail)
            client = models.client.Client(
                data['firstname'],
                data['lastname'],
                data['email'],
                data['city'],
                data['index'],
                data['address']
            )
            # добавляем информацию о пользователе в файл json (код вынесен в модуль db)
            user_id = db.add_user(client)
            # и получаем id

            # генерация URL на страницу информации о пользователе
            
            # создание ссылки
            url = ''.join([SERVER_URL, ':', str(self.server.server_port), f'/user/{user_id}'])
            # создание буфера (чтобы не сохранять изображение в файл)
            buffer = io.BytesIO()
            # создание QR-кода
            img = qrcode.make(url)
            # сохранение изображения
            img.save(buffer, format='PNG')
            # преобразование в base64 в виде, в котором изображение отображает браузер
            result = 'data:image/png;base64,' + base64.b64encode(buffer.getvalue()).decode('utf-8') 

            # подключение шаблонизатора
            
            # Импорт объектов – подключение шаблонизатора Jinja
            from jinja2 import Environment, FileSystemLoader, select_autoescape 
            # Создание среды (это один из основных объектов шаблонизатора Jinja, хранит конфигурацию, используется для загрузки шаблонов)
            env = Environment(
                # загрузка шаблонов из папки
                loader=FileSystemLoader('templates'),
                # экранирование HTML и XML 
                autoescape=select_autoescape(['html', 'xml']))
            # шаблон страницы
            template = env.get_template('qrcode.html')
            # рендеринг страницы
            result = template.render(img_data=result)
            
            # ошибка - вероятнее всего, при создании экземпляра Client (данные не прошли валидацию, определённую в модели)
        except ValueError as e:
            # рендеринг страницы с сообщением (модуль message_view)
            result = message_view.render_message(str(e))

        # преобразование отрендеренной строки (HTML страницы) в utf-8
        result = bytes(result,'utf-8')

        # выдача страницы пользователю
        self.wfile.write(result)

# работа с JSON-файлом (код вынесен в модуль db)
db = DataHandler()
# создание объекта сервера
httpd = HTTPServer(('localhost', 8000), SimpleHTTPRequestHandler)
# запуск сервера
httpd.serve_forever()
