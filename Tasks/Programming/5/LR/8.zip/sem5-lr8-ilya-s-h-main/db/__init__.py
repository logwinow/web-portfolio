import json
from os.path import exists # для проверки существования файла
import models

class DataHandler():
    def __init__(self, filename='users.json'):
        self._filename = filename # сохраняем имя файла во внутреннюю переменную
        self._data = list() # создаём список, в котором будет содержаться информация о пользователе
        if not exists(self._filename): # если файл не найден, создаём его
            with open(self._filename, 'w') as f:
                json.dump([], f) # записываем пустой список
        with open(self._filename, 'r') as f: # открываем файл
            self._data = json.load(f) # загружаем содержимое в self._data
            # это внутренний атрибут (начинается с _), доступен внутри класса
        

    def save_data(self):
        # сохранение данных
        with open(self._filename, 'w') as f:
            json.dump(self._data, f) # сохранение в json формат


    @property
    def clients(self):
        # выдача списка пользователей
        # это свойство (property)
        return self._data


    def get_user_data(self, id):
        # получение информации о пользователе
        # id пользователя - это (индекс+1) элемента в списке, так создаётся ссылка
        # т.е. id первого пользователя - 1, а индекс элемента в списке - 0
        d = self._data[id - 1]
        # возвращается объект Client
        return models.client.Client(
            d['first_name'],
            d['last_name'],
            d['email'],
            d['city'],
            d['index'],
            d['address']
        )
        
        
    def add_user(self, client):
        client = client.client # получение информации о пользователе (свойство client объекта Client)
        self._data.append(client) # добавление в список
        self.save_data() # сохранение данных
        # возвращается id нового пользователя
        # len (длина списка) - т.к. элемент добавляется в конец (см. также строку 34)
        return len(self._data)
