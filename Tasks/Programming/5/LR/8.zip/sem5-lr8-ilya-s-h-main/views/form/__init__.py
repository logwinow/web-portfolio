
def render_form() -> str:
    from jinja2 import Environment, FileSystemLoader, select_autoescape
    env = Environment(
        loader=FileSystemLoader('templates'),
        autoescape=select_autoescape(['html', 'xml']))

    template = env.get_template('form.html')       

    result = template.render(title="Индексная страница")

    return result

# Импорт объектов – подключение шаблонизатора Jinja
# Создание среды (это один из основных объектов шаблонизатора Jinja, хранит конфигурацию, используется для загрузки шаблонов)
# загрузка шаблонов из папки
# экранирование HTML и XML 
