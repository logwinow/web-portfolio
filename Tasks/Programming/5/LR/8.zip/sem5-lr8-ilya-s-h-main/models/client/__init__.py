
class Client():
    def __init__(self, first_name: str, last_name: str, email: str, city: str, index: str, address: str):
        import re

        regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b' # регулярное выражение для проверки e-mail
        # https://www.geeksforgeeks.org/check-if-email-address-valid-or-not-in-python/

        # валидация
        for el in [first_name, last_name, city, address]:
            # проверяем значения полей, в которые должен вводиться текст
            if not el.strip(): # удаляем пробельные символы; если после их удаления строка пуста, выдаём ошибку
                raise ValueError('Поле не может быть пустым')
        if not index.isnumeric():
            # выдаём ошибку, если индекс содержит что-то кроме цифр
            raise ValueError('Указан неверный индекс')
        if not re.fullmatch(regex, email): # проверка e-mail с помощью регулярного выражения
            # выдаём ошибку, если e-mail не является валидным
            raise ValueError('Указан неверный e-mail')
        

        # записываем полученные данные, если они прошли валидацию
        self.__client = {
            "first_name": first_name,
            "last_name": last_name,
            "email": email,
            "city": city,
            "index": index,
            "address": address
        }


    def __str__(self):
        # текстовое представление объекта
        return f'{str(self.__client.get("first_name"))}'


    @property
    def full_name(self):
        # полное имя (свойство)
        return f"{self.__client.get('first_name')} {self.__client.get('last_name')}" 
    

    @property
    def client(self):
        # полная информация (словарь)
        # это свойство
        return self.__client
