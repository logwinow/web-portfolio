def myfoo():
    author = 'Ilya Shumyakin'
    print(f'{author}\'s module is imported')
