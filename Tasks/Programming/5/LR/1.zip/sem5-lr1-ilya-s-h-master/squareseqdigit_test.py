import squareseqdigit


def test_squaresedigit_1():
    assert squareseqdigit.squareSequenceDigit(1) == 1, "squareSequenceDigit(1) == 1"

def test_squaresedigit_2():
    assert squareseqdigit.squareSequenceDigit(2) == 4, "squareSequenceDigit(2) == 4"

def test_squaresedigit_3():
    assert squareseqdigit.squareSequenceDigit(7) == 5, "squareSequenceDigit(7) == 5"

def test_squaresedigit_4():
    assert squareseqdigit.squareSequenceDigit(12) == 6, "squareSequenceDigit(12) == 6"

def test_squaresedigit_5():
    assert squareseqdigit.squareSequenceDigit(17) == 0, "squareSequenceDigit(17) == 0"

def test_squaresedigit_6():
    assert squareseqdigit.squareSequenceDigit(27) == 9, "squareSequenceDigit(27) == 9"
