def squareSequenceDigit(n):
    num = 0
    sequenceLength = 0
    
    while True:
        num += 1
        
        numLength = num ** 2
        length = 1
        while numLength >= 10:
            numLength /= 10
            length += 1
        
        sequenceLength += length
        
        if sequenceLength >= n: 
            return int(num ** 2 / 10**(sequenceLength - n) % 10)
