from squareseqdigit import squareSequenceDigit

if __name__ == '__main__':
    print(squareSequenceDigit(1))
