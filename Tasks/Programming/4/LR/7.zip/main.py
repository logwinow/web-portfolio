import os
import sqlite3

class User():

    def __init__(self, name, height):
        self.__name = name
        self.__height = height

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        print('setter')
        self.__check_name(name)
        self.__name = name

        if name == None:
            del self.name

    @name.deleter
    def name(self):
        print('deleter')

    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, height):
        self.__check_height(height)
        self.__height = height

        if height == None:
            del self.height

    @height.deleter
    def height(self):
        print('deleter')

    def __check_height(self, height):
        pass

    def __check_name(self, name):
        if len(self.name) < 3:
            raise ValueError('Name must contain at least 3 letters.')

    def select(self, conn, sqlquery):
        sqlquery = "SELECT (?,?) FROM user WHERE (???)"
 

def singleton(cls):
    import functools

    instance = None
    
    @functools.wraps(cls)
    def inner(*args, **kwargs):
        nonlocal instance
        print(args, kwargs)
        if instance is None:
            instance = cls(*args, **kwargs)
        return instance

    return inner


@singleton
class Connection():
    '''
    Database connection class.
    '''
    def __init__(self, dbfile, dbtype='sqlite'):
        '''
        Construct a connection object with database.

        :param dbfile: database file
        :param dbtype: database type
        '''
        self.__filename = dbfile
        self.__conn = None
        self.__cursor = None
        if dbtype != 'sqlite':
            raise NotImplementedError('SQLite only is supported.')
        if not os.path.exists(dbfile) or os.stat(dbfile).st_size == 0:
            raise FileNotFoundError('Database file is not found or file is empty.')

    def connect(self):
        '''
        Connects to database and checks if users table exists
        '''
        self.__conn = sqlite3.connect(self.__filename)
        self.__cursor = self.__conn.cursor()
        table_list = self.__conn.execute('SELECT name FROM sqlite_master WHERE type=\'table\' AND name=\'user\'').fetchall()
        if len(table_list) == 0:
            raise Exception('Table is not found.')
        else:
            return self.__conn

    def select(self, id):
        '''
        Retrieves user's information

        :param id: user's ID
        :return User: user object
        '''
        try:
            read_str = f'SELECT * from user WHERE id = {id}'
            data = self.__cursor.execute(read_str)
        except sqlite3.OperationalError as e:
            print(f'Database operation error: {e}')
        else:
            user_data = data.fetchall()[0]
            return User(user_data[2], user_data[1])

    def insert(self, user_data):
        '''
        Adds user to the database table

        :param user_data: user object
        '''
        try:
            insert_str = 'INSERT INTO user (height, name) VALUES (?, ?)'
            self.__cursor.execute(insert_str, (user_data.height, user_data.name))
            self.__conn.commit()
        except sqlite3.OperationalError as e:
            print(f'Database operation error: {e}')
        else:
            print('User was added successfully.')

    def update(self, id, user_data):
        '''
        Updates user information

        :param id: user's ID
        :param user_data: user object
        '''
        try:
            update_str = 'UPDATE user SET name = ?, height = ? WHERE id = ?'
            self.__cursor.execute(update_str, (user_data.name, user_data.height, id))
            self.__conn.commit()
        except sqlite3.OperationalError as e:
            print(f'Database operation error: {e}')
        else:
            print('User updated successfully.')

    def delete(self, id):
        '''
        Deletes user's information from database

        :param id: user's ID
        '''
        try:
            delete_str = 'DELETE FROM user WHERE id = ?'
            self.__cursor.execute(delete_str, (id,))
            self.__conn.commit()
        except sqlite3.OperationalError as e:
            print(f'Database operation error: {e}')
        else:
            print('User deleted successfully.')

    @property
    def conn(self):
        return self.__conn

    @property
    def cursor(self):
        return self.__cursor


c = Connection('zhukov.db')
c.connect()

print(c.select(5).name)

pc_user = User('Katherine', 24.5)
c.insert(pc_user)
user = c.select(18)
print(user.name, user.height)
pc_user.height = 25.23
c.update(18, pc_user)
user = c.select(18)
print(user.name, user.height)
c.delete(23)