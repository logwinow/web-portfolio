from orator import DatabaseManager, Model

config = {
    'default': 'sqlite',
    'sqlite': {
        'driver': 'sqlite',
        'database': 'Chinook_Sqlite.sqlite',
    },
}

db = DatabaseManager(config)
Model.set_connection_resolver(db)
class Artist(Model):
    __table__ = 'Artist'
    __timestamps__ = False
    __primary_key__ = 'ArtistId'
    __fillable__ = ['Name']

# Method select
artist = Artist.find(328)
print('Artist:', artist.ArtistId, artist.Name)

# Method insert
'''
artist = Artist()
artist.name = 'Apollo\'s Fire Baroque Orchestra'
artist.save()
print('New artist:', artist.ArtistId, artist.name)
'''
Artist.create(Name = 'New Era Baroque')
artist = Artist.find(339)
print('Artist:', artist.ArtistId, artist.Name)

# update
artist = Artist.find(329)
artist.Name = 'Academy of Ancient Music'
artist.save()
artist = Artist.find(329)
print('Artist:', artist.ArtistId, artist.Name)

# delete
artist = Artist.create(Name = 'test record')
artist_id = artist.ArtistId
print('Artist:', artist.ArtistId, artist.Name)
Artist.destroy(artist.ArtistId)
'''
artist = Artist.find(artist_id)
print('Artist:', artist.ArtistId, artist.Name)
'''

print('-' * 15)
artists = Artist.where('ArtistId', '>=', 327).take(5).get()
for artist in artists:
    print(artist.ArtistId, artist.Name)