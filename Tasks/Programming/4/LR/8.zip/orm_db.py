from peewee import *

conn = SqliteDatabase('Chinook_Sqlite.sqlite')

class BaseModel(Model):
    class Meta:
        database = conn

class Artist(BaseModel):
    artist_id = AutoField(column_name='ArtistId')
    name = TextField(column_name='Name', null=True)
    class Meta:
        table_name = 'Artist'

def print_new_artists():
    print('-' * 15)
    cur_query = Artist.select().limit(3).order_by(Artist.artist_id.desc())
    for artist in cur_query.dicts().execute():
        print('Artist:', artist)

cursor = conn.cursor()

# One record
artist = Artist.get(Artist.artist_id == 301)
print('Artist:', artist.artist_id, artist.name)

# Many records
query = Artist.select()
print(query)
query = Artist.select().where(Artist.artist_id >= 281).limit(3).order_by(Artist.artist_id.desc())
print(query)

artists_selected = query.dicts().execute()
print(artists_selected)
for artist in artists_selected:
    print('Artist:', artist)

# create records
'''
Artist.create(name='Le Concert d\'Astree')
print_new_artists()

artist = Artist(name='Academy of Ancient Music')
artist.save()
print_new_artists()

artists_data = [{'name': 'Tiento Nuovo'}, {'name': 'Ensemble Matheus'}]
Artist.insert_many(artists_data).execute()
print_new_artists()
'''

# update records
artist = Artist(name='Baroque Ensemble Matheus')
artist.artist_id = 331
artist.save()
print_new_artists()

'''
query = Artist.update(name=Artist.name + '!').where(Artist.artist_id >= 329)
query.execute()
print_new_artists()
'''

# delete records
'''
Artist.create(name='test record')
print_new_artists()
artist = Artist.get(Artist.artist_id == 332)
artist.delete_instance()
print_new_artists()
'''
query = Artist.delete().where(Artist.artist_id > 331)
query.execute()
print_new_artists()
conn.close()