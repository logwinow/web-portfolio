# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.

# pip install orator
# pip install mysql-connector-python (without ORM)
# pip install mysqlclient (with ORM)

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press ⌘F8 to toggle the breakpoint.

    # import mysql.connector
    from orator import DatabaseManager

    config = {
        'default': 'sqlite',
        'sqlite': {
            'driver': 'sqlite',
            'database': 'zhukov.db',
        },
        'mysql': {
            'driver': 'mysql',
            'host': 'localhost',
            'database': 'simpledb',
            'user': 'root',
            'password': 'KGuCtHKdd3oWhZBQPQxiNGGi',
            'prefix': ''
        },
    }

    # db = DatabaseManager(config)
    db = DatabaseManager(config)
    # r = db.statement('SHOW DATABASES;')
    # print(type(r))

    res = db.select(
        "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY 1")
    print(res)
    #
    # db.insert('INSERT INTO user (name) values (?)', ['Ivan'])
    #
    res = db.select("SELECT id,name FROM user WHERE id=6")
    for r in res:
        print(f"#{r['id']} name: {r['name']}")
    #
    # users = db.table('user').get()
    # for user in users:
    #     print(user['name'])
    # print(res)
    # #
    from orator import Model
    Model.set_connection_resolver(db)

    class User(Model):
        __table__ = 'user'
        __timestamps__ = False

    #
    #
    user = User.find(6)
    print(user.name)
    # Insert
    user2 = User()
    user2.name = 'Konstantin'
    user2.save()

    # Update 
    user3 = User.find(48)
    user3.name = 'Konstantin Velikij'
    user3.height = 10
    user3.save()

    user = User.find(48)
    print(f'Имя: {user.name}, Рост: {user.height}')



    # #
    # res = db.select("SELECT id,name FROM user")
    # for r in res:
    #     print(f"#{r['id']} name: {r['name']}")
    # print(res)
    #
    #
    # # class Book(Model):
    # #     pass


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
