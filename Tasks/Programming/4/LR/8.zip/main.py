import sqlite3
conn = sqlite3.connect('Chinook_Sqlite.sqlite')
cursor = conn.cursor()

# Method select
cursor.execute("SELECT Name FROM Artist ORDER BY Name LIMIT 3")
results = cursor.fetchall()
print(results)

# Method insert
cursor.execute("INSERT INTO Artist VALUES (NULL, 'Barocca Moderna')")
conn.commit()
cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
results = cursor.fetchall()
print(results)

# execute many
cursor.executescript("""
INSERT INTO Artist VALUES (NULL, 'Academy of St Martin in the Fields');
INSERT INTO Artist VALUES (NULL, 'Les Arts Florissants');
""")
cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
results = cursor.fetchall()
print(results)

# placeholders // ordered
cursor.execute("SELECT Name FROM Artist ORDER BY Name LIMIT ?", ('3'))
results = cursor.fetchall()
print(results)

# named
cursor.execute("SELECT Name FROM Artist ORDER BY Name LIMIT :limit", {'limit': 3})
results = cursor.fetchall()
print(results)

# insert many
new_artists = [
    ('Barocca Moderna',),
    ('Academy of St Martin in the Fields',),
    ('Les Arts Florissants',)]
cursor.executemany("INSERT INTO Artist VALUES (NULL, ?)", new_artists)
cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
results = cursor.fetchall()
print(results)

# fetchone
cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
print(cursor.fetchone())

# iterator
for artist in cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3"):
    print(artist)
conn.close()