import sqlite3

try:
    conn = sqlite3.connect('zhukov.db')
except sqlite3.DatabaseError as e:
    print(f'Connection error: {e}')
c = conn.cursor()

def get_table_info():
    data_str = 'PRAGMA table_info(user)'
    data = c.execute(data_str)
    print('\t'.join(['cid', 'name', 'type', 'notnull', 'default', 'pk']))
    for row in data:
        print(row)

def read_all():
    try:
        crud_read_str = 'SELECT * from user'
        crud_res = c.execute(crud_read_str)
    except sqlite3.OperationalError as e:
        print(f'Database operation error: {e}')
    else:
        for r in crud_res:
            print(r)

def read_user(id):
    try:
        read_str = f'SELECT * from user WHERE id = {id}'
        data = c.execute(read_str)
    except sqlite3.OperationalError as e:
        print(f'Database operation error: {e}')
    else:
        return data.fetchall()[0]

def add_user(name, height):
    try:
        insert_str = 'INSERT INTO user (height, name) VALUES (?, ?)'
        c.execute(insert_str, (height, name))
        conn.commit()
    except sqlite3.OperationalError as e:
        print(f'Database operation error: {e}')
    else:
        print('User was added successfully.')

def update_user(id, name=None, height=None):
    if not name and not height:
        print('Nothing to update.')
        return
    else:
        try:
            if name:
                update_str = 'UPDATE user SET name = ? WHERE id = ?'
                c.execute(update_str, (name, id))
            if height:
                update_str = 'UPDATE user SET height = ? WHERE id = ?'
                c.execute(update_str, (height, id))
            conn.commit()
        except sqlite3.OperationalError as e:
            print(f'Database operation error: {e}')
        else:
            print('User updated successfully.')

def delete_user(id):
    try:
        delete_str = 'DELETE FROM user WHERE id = ?'
        c.execute(delete_str, (id,))
        conn.commit()
    except sqlite3.OperationalError as e:
        print(f'Database operation error: {e}')
    else:
        print('User deleted successfully.')

read_all()
print(read_user(1))
update_user(7, name='new user', height=3.5)
read_all()
delete_user(10)
read_all()
conn.close()