import main
import timeit

print(timeit.timeit(lambda: main.gen_bin_tree(2, 5), number=10000))
print(timeit.timeit(lambda: main.gen_bin_tree_non_rec(2, 5), number=10000))