def gen_bin_tree(height, root):
    # 1. рекурсивное решение
    if height < 1:
        raise ValueError("Высота не может быть меньше 1!")    
    left_leaf = root**3
    right_leaf = (root*2-1)

    tree = {str(root): []}
    if height == 1:
        return tree
    height -=1

    tree[str(root)] = [gen_bin_tree(height, left_leaf), gen_bin_tree(height, right_leaf)]
    return tree

def gen_bin_tree_non_rec(height, root, left_leaf, right_leaf):
  # 2. Не рекурсивное решение
    roots = [[root]]

    for leaf in range(height - 1):
        if len(roots) == 1:
            r = roots[0]
        else:
            r = [item for s in roots[-1] for item in s]

        leaves = list(map(lambda root_value: [left_leaf(root_value), right_leaf(root_value)], r))

        roots.append(leaves)

    roots.reverse()

    tree = dict()
    
    roots[-1] = [roots[-1]]
    roots[0] = list(map(lambda x: [{str(x[0]): []}, {str(x[1]): []}], roots[0]))
    for i in range(height-1):
        sublist = roots[i]
        l = len(sublist)
        for j in range(l):
            x = sublist.pop(0)
            roots[i+1][j // 2][j % 2] = {str(roots[i+1][j // 2][j % 2]):x}
    tree = roots[-1][0][0]
    return tree


def left_leaf(root):
    return root**3


def right_leaf(root):
    return root*2 - 1


def main():
    # Функция main должна позволять вводить данные и
    # вызывать искомую функцию (gen_bin_tree) и
    # возврщать ответ с помощью print

    height = 4
    root = 12
    print(gen_bin_tree(root, height))
    print(gen_bin_tree_non_rec(root, height, left_leaf, right_leaf))

if __name__ == '__main__':
 main()
