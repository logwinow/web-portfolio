import main
import unittest

class TestBinTreeGeneration(unittest.TestCase):

    def test_rec(self):
        self.assertEqual(main.gen_bin_tree(1, 12), {'12': [{'1728': []}, {'23': []}]})
        self.assertEqual(main.gen_bin_tree(3, 5), {'12': [{'1728': [{'5159780352': []}, {'3455': []}]}, {'23': [{'45': []}, {'12167': []}]}]})

    def test_rec_exceptions(self):
        self.assertRaises(ValueError, main.gen_bin_tree, -2, 3)
        self.assertRaisesRegex(ValueError, 'Высота не может быть меньше 1!', main.gen_bin_tree, -3, 5)

    # assert type(gen_bin_tree(
    #     1, 5).get("5")) is list, " Примитивный тест для height=1, root=5"
    # assert type(gen_bin_tree(1, 5)) is dict, "Вернули ли мы словарь?"
    # assert type(gen_bin_tree(2, 5).get("5")[0].get(
    #     "8")) is list, "Тест для левого поддерева, должен быть  лист"
    # assert len(gen_bin_tree(2, 5).get("5")[0].get(
    #     "8")) == 0, "Тест для длины левого поддерева, должен быть пустой list"

if __name__ == '__main__':
    unittest.main() 


