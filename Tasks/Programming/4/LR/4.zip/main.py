import json


def load_json(f):
    """
    Считывание и загрузка json

    :param f:
    :return:
    """
    # TODO: Исследуйте что такое :param f:, :return: здесь и впишите то, что там должно быть

    import json
    res = []
    data = json.load(f)
    for el in data:
        res.append((el['name'], el['email']))
        print(el['name'], el['email'])

    return res


def print_json():
    """
    Вывод данных из json на экран с pprint

    :param f:
    :return:
    """
    pass  # TODO: Вывод данных с помощью pprint


def save_json(f):
    """
    Сохранение полученных данных в json-файл

    :param f:
    :return:
    """

    # TODO: Исследуйте что такое :param f:, :return: здесь и впишите то, что там должно быть

    pass  # TODO: Реализуйте вместо pass функцию по сохранению данных в файле json


def add_users_data():
    """
    Добавление данных о пользователях с клавиатуры

    :return:
    """
    # TODO: Исследуйте что такое :return: здесь и впишите то, что там должно быть
    pass  # TODO: Добавление данных с клавиатуры в json


# TODO: Реализуйте обработку исключений внутри соответствующей функции
try:
    f = open('data.json'
             )  # TODO: Проверить права на доступ к файлу с помощь access()
    # https://docs-python.ru/standart-library/modul-os-python/funktsija-access-modulja-os/

except PermissionError as e:
    print(f'File open error: {e}')
    print('Попытка сменить права на чтение файла')

    import os
    import stat

    try:
        os.chmod('data.json', stat.S_IRWXU)
    except OSError as e:
        print(f'Попытка смены прав не удалась: {e}')
    else:
        f = open('data.json')
        r = load_json(f)
else:
# r = load_json(f)
    f.close()  # выполнится только в том случае файл если файл был открыт
finally:
    print('Завершение программы')

# TODO Перенести код внутрь функций add_users_data, save_json
f = open('data-output.json', 'w')
name = input("Enter name: ")
email = input("Enter email: ")

new_name_dict = {'name': name, 'email': email}

serialized_data = json.dumps(new_name_dict)

print(type(serialized_data))

f.writelines([
    serialized_data,
])

f.close()

if __name__ == '__main__':
    pass
    # запуск функций load_json,  save_json, add_users_data
